library(pins)

board <- board_s3(
  "rph2024-haunted-app-sessions"
)

board |> pin_write(mtcars)
